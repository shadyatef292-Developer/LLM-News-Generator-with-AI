=== LLM News Studio Pro ===
Contributors: [Shady Atef]
Requires at least: 5.8
Tested up to: 6.4.2
Stable tag: 5.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The Enterprise-Grade Content Engine for WordPress, leveraging Groq for speed and Unsplash for legal images.

== Description ==

LLM News Studio Pro is a highly optimized WordPress plugin designed for automated, high-quality content generation. It utilizes the speed of Groq's low-latency inference engine to produce SEO-ready news articles tailored to any specific niche defined by the user prompt.

**Key Features:**

* **⚡ Groq-Powered Speed:** Generates comprehensive articles in seconds.
* **📸 Automatic Featured Images:** Integrates with the Unsplash API to find and legally attribute relevant, high-quality featured images, enhancing content engagement.
* **✅ SEO Ready:** Automatically enforces structured content (H2s, lists), sets meta descriptions (Excerpts), and populates tags (Keywords) for maximum search visibility.
* **🛡️ Secure & Performant:** All heavy operations are confined to the admin and Cron system, ensuring zero impact on frontend site speed.
* **🔄 Daily Automation:** Fully configurable scheduler to automatically produce content 24/7.

**Architecture:**

The plugin is built using modern PHP standards, employing object-oriented programming (OOP) and class separation (Settings, Generator, Assets) for superior maintainability and adherence to WordPress best practices.

== Installation ==

1. Upload the `llm-news-studio-pro` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Navigate to the new **LLM News Studio** menu item to configure your API keys.

**API Key Requirements (Crucial Step):**

* **Groq API Key:** Obtainable from [https://console.groq.com/keys](https://console.groq.com/keys).
* **Unsplash Access Key (Client ID):** Obtainable from [https://unsplash.com/developers](https://unsplash.com/developers).

== Frequently Asked Questions ==

= How do I prevent the "Save Changes" button from generating a post? =

The plugin is already protected. The **Save Settings Only** button uses a separate action and ensures the daily automation starts 1 hour later, preventing any instant post creation when saving configuration.

= Why are images not attaching to my posts? =

This is usually due to one of three issues: 1) Incorrect Unsplash Access Key, 2) The Groq post title is too generic (try improving your main Topic Prompt), or 3) Your server has firewall restrictions preventing the `download_url` function from fetching the image file (check your host for cURL or file downloading restrictions).

== Changelog ==

= 5.1.0 (2025-11-27) =
* **Architecture Refactor:** Moved to a robust OOP structure with separated classes (Generator, Settings, Assets) for professionalism and maintainability.
* **Asset Management:** Implemented professional CSS enqueuing via `wp_add_inline_style`.

= 5.0.0 =
* **Critical Fix:** Resolved the bug where "Save Settings" triggered immediate post generation (Cron timestamp fix).
* **Image System Upgrade:** Implemented robust `download_url` and `media_handle_sideload` for higher success rates on image attachments.
* **UI Polish:** Finalized the professional dashboard aesthetic.